  // tạo biến bảng điểm 
  var arrBangDiem=[];

  // tạo các biến 
  
  $(document).ready(function(){
    $('#btnNhap').click(function(){
        var name = $('#name').val();
        var math = $('#math').val();
        var physical = $('#physical').val();
        var chemistry = $('#chemistry').val();

        var testScore = { 
              name: name,
              math: math,
              physical: physical,
              chemistry: chemistry,
        };
          // console.log(testScore)
        arrBangDiem.push(testScore)
        in_danhsach();
        resetForm()
      });
    function in_danhsach(){
        // xóa dữ liệu trong Row
        var table = document.getElementById('table');
        for (var i = table.rows.length - 1; i>0;i -- ){
            table.deleteRow(i);
        }

          // duyet bảng điểm
        for (var i =0 ; i<arrBangDiem.length;i++){
            var obj = arrBangDiem[i];
            // tao 1 row mới
            $('#table tbody').append($('<tr>')
            .append($('<td>').append(i+1))
            .append($('<td>').append(obj.name))
            .append($('<td>').append(obj.math))
            .append($('<td>').append(obj.physical))
            .append($('<td>').append(obj.chemistry))
            .append($('<td>').append('?'))
            )
        }    
    }
    function resetForm(){
        $('#name').val("");
        $('#math').val("");
        $('#physical').val("");
        $('#chemistry').val("");
    }

  });