
public interface ICalculator {
//  Hàm tính lương cho nhân viên
	public double calculateSalary();

}
