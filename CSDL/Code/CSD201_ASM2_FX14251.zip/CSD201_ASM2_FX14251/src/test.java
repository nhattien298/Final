public class test {
    public static void main(String[] args) {
        Product p1 = new Product();
        p1.setbCode("0123456");
        p1.setTitle("sua vinamiik");
        p1.setQuantity(15);
        p1.setPrice(45.2);
        System.out.println(p1);
    }
}
