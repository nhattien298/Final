package sort;

import java.util.Arrays;
import java.util.Scanner;

import static sort.Algorithm.*;

public class Main_Sort {
    public static void main(String[] args) {

    while (run){
        menu();
    }

    }


}
